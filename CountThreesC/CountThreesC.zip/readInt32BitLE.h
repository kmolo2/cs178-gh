/*
 * readInt32BitLE.h
 *
 *  Created on: Sep 10, 2014
 *      Author: taxi
 */

#ifndef READINT32BITLE_H_
#define READINT32BITLE_H_

#include <stdio.h>

int readInt32BitLE(FILE *inFile);

#endif /* READINT32BITLE_H_ */
